# Trix Icons

Trix's toolbar uses [Material Design Icons by Google][1], which are licensed under the [Creative Commons Attribution 4.0 International License (CC-BY 4.0)][2]. Some icons have been modified.

[1]: https://github.com/google/material-design-icons
[2]: https://github.com/google/material-design-icons/blob/master/LICENSE
