| Q                | A
| ---------------- | ---
| Bug fix?         | yes/no
| New feature?     | yes/no
| BC breaks?       | yes/no
| Deprecations?    | yes/no
| New tests added? | yes/not needed
| Fixed tickets    | comma-separated list of tickets fixed by the PR, if any
| License          | MIT

### Description

[Description of the bug or feature]

--

#### Please, don't submit `/dist` files with your PR!
